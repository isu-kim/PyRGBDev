"""
@project : pyrgbdevDemos
@author : Gooday2die
@date : 2022-02-14
@file : __init__.py
"""

__author__ = "Gooday2die"
__copyright__ = "Copyright 2022, pyrgbdev"

__license__ = "MIT"
__version__ = "1.0.0"
__maintainer__ = "Gooday2die"
__email__ = "edina00@naver.com"
__status__ = "Demonstration"
